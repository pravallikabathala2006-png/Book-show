document.getElementById("bookButton").addEventListener("click", function () {
    let movie = document.getElementById("movie").value;
    let theatre = document.getElementById("theatre").value;
    let time = document.getElementById("time").value;
    let seats = document.getElementById("seats").value;

    if (movie === "" || theatre === "" || time === "" || seats === "") {
        alert("Please select all booking details.");
        return;
    }

    document.getElementById("confirmation").innerHTML =
        "✅ <b>Booking Successful!</b><br><br>" +
        "🎬 Movie: " + movie + "<br>" +
        "🏢 Theatre: " + theatre + "<br>" +
        "🕐 Show Time: " + time + "<br>" +
        "💺 Seats: " + seats;

    setTimeout(function () {
        window.close();
    }, 3000);
});